# Project 4 Submission
Part 1 and 2 are meant to be viewed through the .mlx files.
The following files needed to view the report are:
    - part1.mlx
    - part2.mlx
    
Thank you for reading and your time! (Happy holidays!)